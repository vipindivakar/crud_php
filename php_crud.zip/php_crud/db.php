<?php
mysql_select_db('crud',mysqli_connect('localhost','root',''))or die(mysql_error());
?>